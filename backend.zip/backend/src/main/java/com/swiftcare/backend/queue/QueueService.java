package com.swiftcare.backend.queue;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import com.swiftcare.backend.common.enums.QueueStatus;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class QueueService {

    private static final int DEFAULT_CONSULTATION_MINUTES = 15;

    private final QueueEntryRepository queueEntryRepository;

    @Transactional(readOnly = true)
    public List<DoctorQueueResponse> getDepartmentQueue(
            Long departmentId
    ) {
        List<QueueEntry> entries =
                queueEntryRepository
                        .findByDepartmentIdAndStatusOrderBySeverityScoreDescPremiumDescScheduledTimeAsc(
                                departmentId,
                               QueueStatus.WAITING
                        );

        List<DoctorQueueResponse> response = new ArrayList<>();

        for (int index = 0; index < entries.size(); index++) {
            QueueEntry entry = entries.get(index);

            int queuePosition = index + 1;

            int estimatedWaitMinutes =
                    index * DEFAULT_CONSULTATION_MINUTES;

            response.add(
                    mapToDoctorQueueResponse(
                            entry,
                            queuePosition,
                            estimatedWaitMinutes
                    )
            );
        }

        return response;
    }

    @Transactional
    public QueueEntry createQueueEntry(
            UUID patientId,
            Long departmentId,
            String patientName,
            String patientNumber,
            Integer age,
            String gender,
            String chiefComplaint,
            Integer severityScore,
            LocalDateTime scheduledTime,
            Boolean premium
    ) {
        validateSeverityScore(severityScore);

        QueueEntry entry = QueueEntry.builder()
                .patientId(patientId)
                .departmentId(departmentId)
                .patientName(patientName)
                .patientNumber(patientNumber)
                .age(age)
                .gender(gender)
                .chiefComplaint(chiefComplaint)
                .severityScore(severityScore)
                .severityLabel(calculateSeverityLabel(severityScore))
                .scheduledTime(scheduledTime)
                .premium(Boolean.TRUE.equals(premium))
.emergency(severityScore >= 9)
                .status(QueueStatus.WAITING)
                .createdAt(LocalDateTime.now())
                .build();

        return queueEntryRepository.save(entry);
    }

    @Transactional
    public QueueEntry callPatient(UUID queueEntryId) {
        QueueEntry entry = findQueueEntry(queueEntryId);

        ensurePatientIsWaiting(entry);

        entry.setStatus(QueueStatus.CALLED);

        return queueEntryRepository.save(entry);
    }

@Transactional
public QueueEntry startConsultation(UUID queueEntryId) {
    QueueEntry entry = findQueueEntry(queueEntryId);

    if (entry.getStatus() == QueueStatus.COMPLETED) {
        throw new IllegalStateException(
                "This consultation has already been completed."
        );
    }

    if (entry.getStatus() == QueueStatus.CANCELLED) {
        throw new IllegalStateException(
                "A cancelled queue entry cannot start consultation."
        );
    }

    entry.setStatus(QueueStatus.CALLED);

    return queueEntryRepository.save(entry);
}
@Transactional
public QueueEntry completeConsultation(UUID queueEntryId) {
    QueueEntry entry = findQueueEntry(queueEntryId);

    if (entry.getStatus() != QueueStatus.CALLED) {
        throw new IllegalStateException(
                "The patient must be called before the consultation is completed."
        );
    }

    entry.setStatus(QueueStatus.COMPLETED);

    return queueEntryRepository.save(entry);
}
    @Transactional
    public QueueEntry cancelQueueEntry(UUID queueEntryId) {
        QueueEntry entry = findQueueEntry(queueEntryId);

      if (entry.getStatus() == QueueStatus.COMPLETED) {
            throw new IllegalStateException(
                    "A completed queue entry cannot be cancelled."
            );
        }

        entry.setStatus(QueueStatus.CANCELLED);

        return queueEntryRepository.save(entry);
    }

    @Transactional(readOnly = true)
    public QueueEntry findQueueEntry(UUID queueEntryId) {
        return queueEntryRepository
                .findById(queueEntryId)
                .orElseThrow(
                        () -> new IllegalArgumentException(
                                "Queue entry was not found."
                        )
                );
    }

    private DoctorQueueResponse mapToDoctorQueueResponse(
            QueueEntry entry,
            int queuePosition,
            int estimatedWaitMinutes
    ) {
        return DoctorQueueResponse.builder()
                .id(entry.getId())
                .patientId(entry.getPatientId())
                .patientName(entry.getPatientName())
                .patientNumber(entry.getPatientNumber())
                .age(entry.getAge())
                .gender(entry.getGender())
                .chiefComplaint(entry.getChiefComplaint())
                .severityScore(entry.getSeverityScore())
                .severityLabel(entry.getSeverityLabel())
                .scheduledTime(entry.getScheduledTime())
                .queuePosition(queuePosition)
                .estimatedWaitMinutes(estimatedWaitMinutes)
                .status(entry.getStatus().name())
.isEmergency(entry.isEmergency())
                .premium(entry.isPremium())
                .build();
    }

private void ensurePatientIsWaiting(QueueEntry entry) {
    if (entry.getStatus() != QueueStatus.WAITING) {
        throw new IllegalStateException(
                "Only a waiting patient can be called."
        );
    }
}
    private void validateSeverityScore(Integer score) {
        if (score == null || score < 0 || score > 10) {
            throw new IllegalArgumentException(
                    "Severity score must be between 0 and 10."
            );
        }
    }

    private String calculateSeverityLabel(Integer score) {
        if (score >= 9) {
            return "CRITICAL";
        }

        if (score >= 7) {
            return "SEVERE";
        }

        if (score >= 4) {
            return "MODERATE";
        }

        return "MILD";
    }
}