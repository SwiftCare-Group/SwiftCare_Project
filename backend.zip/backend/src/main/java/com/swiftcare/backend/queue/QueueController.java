package com.swiftcare.backend.queue;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequiredArgsConstructor
public class QueueController {

    private final QueueService queueService;

    @GetMapping("/departments/{departmentId}/queue")
    public ResponseEntity<List<DoctorQueueResponse>>
    getDepartmentQueue(
            @PathVariable Long departmentId
    ) {
        return ResponseEntity.ok(
                queueService.getDepartmentQueue(departmentId)
        );
    }

    @PatchMapping("/queue/{queueEntryId}/call")
    public ResponseEntity<QueueEntry> callPatient(
            @PathVariable UUID queueEntryId
    ) {
        return ResponseEntity.ok(
                queueService.callPatient(queueEntryId)
        );
    }

    @PatchMapping("/queue/{queueEntryId}/start")
    public ResponseEntity<QueueEntry> startConsultation(
            @PathVariable UUID queueEntryId
    ) {
        return ResponseEntity.ok(
                queueService.startConsultation(queueEntryId)
        );
    }

    @PatchMapping("/queue/{queueEntryId}/complete")
    public ResponseEntity<QueueEntry> completeConsultation(
            @PathVariable UUID queueEntryId
    ) {
        return ResponseEntity.ok(
                queueService.completeConsultation(queueEntryId)
        );
    }

    @PatchMapping("/queue/{queueEntryId}/cancel")
    public ResponseEntity<QueueEntry> cancelQueueEntry(
            @PathVariable UUID queueEntryId
    ) {
        return ResponseEntity.ok(
                queueService.cancelQueueEntry(queueEntryId)
        );
    }
}